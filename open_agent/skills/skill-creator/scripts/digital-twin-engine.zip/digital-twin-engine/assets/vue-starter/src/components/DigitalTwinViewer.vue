<template>
  <div class="digital-twin-viewer">
    <div ref="container" class="cesium-container"></div>
    <div id="main-sidebar"></div>
    <div v-if="loading" class="loading">
      <span>正在加载数字孪生引擎...</span>
    </div>
    <div v-if="error" class="loading error">
      <span>加载失败: {{ error }}</span>
    </div>
  </div>
</template>

<script>
export default {
  name: 'DigitalTwinViewer',
  data() {
  return {
  loading: true,
  error: null,
  engine: null,
  viewer: null,
  environmentControl: null,
  sidebarControl: null
  };
  },
  mounted() {
    this.initEngine();
  },
  beforeUnmount() {
    this.cleanup();
  },
  methods: {
    async initEngine() {
      try {
        const lacdt = window.LACDT;
        if (!lacdt) {
          throw new Error('LACDT SDK 未加载');
        }

        // Initialize Engine
        this.engine = new LACDT.Engine({ 
          container: this.$refs.container 
        });
        this.viewer = this.engine.viewer;

        // Configure time
        const now = new Date();
        now.setHours(12, 0, 0, 0);
        this.viewer.clock.currentTime = Cesium.JulianDate.fromDate(now);
        this.viewer.clock.shouldAnimate = false;

        // Add imagery
        await this.addImageryLayers();

        // Add terrain
        await this.addTerrain();

        // Initialize environment control
        this.initEnvironmentControl();

        // Initialize UI
        this.initUI();

        // Set camera
        this.viewer.camera.setView({
          destination: Cesium.Cartesian3.fromDegrees(109, 36, 20000000)
        });

        this.loading = false;
        console.log('Digital Twin Engine initialized successfully!');

      } catch (error) {
        console.error('Initialization error:', error);
        this.error = error.message;
        this.loading = false;
      }
    },

    async addImageryLayers() {
      const token = 'b429e0b67c10e0b11ff4c061aec36c86f1394c007e54c131d57c8abc7435c51f';

      // Base imagery
      const geovisMap = new Cesium.UrlTemplateImageryProvider({
        url: `https://tiles.geovisearth.com/base/v1/img/{z}/{x}/{y}?format=webp&tmsIds=w&token=${token}`,
        maximumLevel: 18
      });
      this.viewer.imageryLayers.addImageryProvider(geovisMap);

      // Annotations
      const geovisCia = new Cesium.UrlTemplateImageryProvider({
        url: `https://tiles.geovisearth.com/base/v1/cia/{z}/{x}/{y}?format=webp&tmsIds=w&token=${token}`,
        maximumLevel: 18
      });
      this.viewer.imageryLayers.addImageryProvider(geovisCia);
    },

    async addTerrain() {
      const token = 'b429e0b67c10e0b11ff4c061aec36c86f1394c007e54c131d57c8abc7435c51f';
      const terrainProvider = await Cesium.CesiumTerrainProvider.fromUrl(
        `https://tiles.geovisearth.com/base/v1/terrain?token=${token}`,
        { requestWaterMask: true, requestVertexNormals: true }
      );
      this.viewer.terrainProvider = terrainProvider;
    },

    initEnvironmentControl() {
      this.environmentControl = new window.LACDT.EnvironmentControl({
        renderConfig: {
          engine: this.engine,
          visible: false,
          viewer: this.viewer,
          directionalLight: {
            enabled: false,
            followSun: true,
            direction: new Cesium.Cartesian3(1.51, -0.11, 0.21),
            intensity: 2.5,
            color: Cesium.Color.fromCssColorString("#303941"),
            ambientIntensity: 0.7
          },
          shadow: { enabled: false, size: 4096, softShadows: true, darkness: 0.51 },
          atmosphereScattering: { enabled: false, atmosphereIntensity: 0.91 },
          volumetricClouds: { enabled: false },
          postProcessing: { enabled: false, hdrEnabled: true, fxaaEnabled: true }
        }
      });
    },

    initUI() {
      const lacdt = window.LACDT;
      const render = this.environmentControl.render;

      // Sidebar
      this.sidebarControl = new lacdt.SidebarControl({
        containerId: 'main-sidebar',
        defaultActive: 'scene',
        initiallyExpanded: false,
        panelConfig: {
          defaultWidth: 400,
          defaultHeight: '85vh',
          sidebarExpandedWidth: 200,
          sidebarCollapsedWidth: 72,
          zIndex: 1000
        }
      });

      // Controls
      const sceneControl = new lacdt.SceneControl(render, { width: 350, height: '85vh', position: 'right', zIndex: 1000 });
      const tilesetSearchControl = new lacdt.TilesetSearchControl(render);
      const layerControl = new lacdt.LayerControl(render, { width: 350, height: '85vh', position: 'right', zIndex: 1000 });
      const buildingControl = new lacdt.BuildingControl(render, { width: 350, height: '85vh', position: 'right', zIndex: 1000 });
      const toolControl = new lacdt.ToolboxControl(render, { width: 350, height: '85vh', position: 'right', zIndex: 1000 });
      const plottingControl = new lacdt.PlottingControl(render, { configPath: './plot_data.json' });

      // Register panels
      this.sidebarControl.registerPanel('plotting', plottingControl);
      this.sidebarControl.registerPanel('3DTile', tilesetSearchControl);
      this.sidebarControl.registerPanel('layer', layerControl);
      this.sidebarControl.registerPanel('building', buildingControl);
      this.sidebarControl.registerPanel('scene', sceneControl);
      this.sidebarControl.registerPanel('toolbox', toolControl);
    },

    cleanup() {
      if (this.viewer) {
        this.viewer.destroy();
        this.viewer = null;
      }
      this.engine = null;
      this.environmentControl = null;
      this.sidebarControl = null;
    }
  }
};
</script>

<style scoped>
.digital-twin-viewer {
  width: 100%;
  height: 100vh;
  position: relative;
  overflow: hidden;
}

.cesium-container {
  width: 100%;
  height: 100%;
}

.loading {
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
  background: rgba(0, 0, 0, 0.8);
  color: #fff;
  padding: 20px 40px;
  border-radius: 8px;
  font-family: Arial, sans-serif;
  z-index: 1000;
}

.loading.error {
  background: rgba(139, 0, 0, 0.9);
}
</style>
