import React from 'react';
import DigitalTwinViewer from './components/DigitalTwinViewer';

function App() {
  return (
    <div className="App" style={{ width: '100vw', height: '100vh' }}>
      <DigitalTwinViewer />
    </div>
  );
}

export default App;
