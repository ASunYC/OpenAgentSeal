import React, { useEffect, useRef, useState } from 'react';

function DigitalTwinViewer() {
  const containerRef = useRef(null);
  const engineRef = useRef(null);
  const viewerRef = useRef(null);
  const environmentControlRef = useRef(null);
  const sidebarControlRef = useRef(null);
  
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const initEngine = async () => {
      try {
        const lacdt = window.LACDT;
        if (!lacdt) {
          throw new Error('LACDT SDK 未加载');
        }

        // Initialize Engine
        engineRef.current = new LACDT.Engine({ 
          container: containerRef.current 
        });
        viewerRef.current = engineRef.current.viewer;

        // Set fixed time to noon
        const now = new Date();
        now.setHours(12, 0, 0, 0);
        viewerRef.current.clock.currentTime = Cesium.JulianDate.fromDate(now);
        viewerRef.current.clock.shouldAnimate = false;

        // Add imagery and terrain
        await addImageryLayers();
        await addTerrain();

        // Initialize controls
        initEnvironmentControl();
        initUI();

        // Set camera view
        viewerRef.current.camera.setView({
          destination: Cesium.Cartesian3.fromDegrees(109, 36, 20000000)
        });

        setLoading(false);
        console.log('Digital Twin Engine initialized successfully!');

      } catch (err) {
        console.error('Initialization error:', err);
        setError(err.message);
        setLoading(false);
      }
    };

    const addImageryLayers = async () => {
      const token = 'b429e0b67c10e0b11ff4c061aec36c86f1394c007e54c131d57c8abc7435c51f';

      // Base imagery
      const geovisMap = new Cesium.UrlTemplateImageryProvider({
        url: `https://tiles.geovisearth.com/base/v1/img/{z}/{x}/{y}?format=webp&tmsIds=w&token=${token}`,
        maximumLevel: 18
      });
      viewerRef.current.imageryLayers.addImageryProvider(geovisMap);

      // Annotations
      const geovisCia = new Cesium.UrlTemplateImageryProvider({
        url: `https://tiles.geovisearth.com/base/v1/cia/{z}/{x}/{y}?format=webp&tmsIds=w&token=${token}`,
        maximumLevel: 18
      });
      viewerRef.current.imageryLayers.addImageryProvider(geovisCia);
    };

    const addTerrain = async () => {
      const token = 'b429e0b67c10e0b11ff4c061aec36c86f1394c007e54c131d57c8abc7435c51f';
      const terrainProvider = await Cesium.CesiumTerrainProvider.fromUrl(
        `https://tiles.geovisearth.com/base/v1/terrain?token=${token}`,
        { requestWaterMask: true, requestVertexNormals: true }
      );
      viewerRef.current.terrainProvider = terrainProvider;
    };

    const initEnvironmentControl = () => {
      environmentControlRef.current = new window.LACDT.EnvironmentControl({
        renderConfig: {
          engine: engineRef.current,
          visible: false,
          viewer: viewerRef.current,
          directionalLight: {
            enabled: false,
            followSun: true,
            direction: new Cesium.Cartesian3(1.51, -0.11, 0.21),
            intensity: 2.5,
            color: Cesium.Color.fromCssColorString("#303941"),
            ambientIntensity: 0.7
          },
          shadow: { enabled: false, size: 4096, softShadows: true, darkness: 0.51 },
          atmosphereScattering: { enabled: false, atmosphereIntensity: 0.91 },
          volumetricClouds: { enabled: false },
          postProcessing: { enabled: false, hdrEnabled: true, fxaaEnabled: true }
        }
      });
    };

    const initUI = () => {
      const lacdt = window.LACDT;
      const render = environmentControlRef.current.render;

      sidebarControlRef.current = new lacdt.SidebarControl({
        containerId: 'main-sidebar',
        defaultActive: 'scene',
        initiallyExpanded: false,
        panelConfig: {
          defaultWidth: 400,
          defaultHeight: '85vh',
          sidebarExpandedWidth: 200,
          sidebarCollapsedWidth: 72,
          zIndex: 1000
        }
      });

      const sceneControl = new lacdt.SceneControl(render, { width: 350, height: '85vh', position: 'right', zIndex: 1000 });
      const tilesetSearchControl = new lacdt.TilesetSearchControl(render);
      const layerControl = new lacdt.LayerControl(render, { width: 350, height: '85vh', position: 'right', zIndex: 1000 });
      const buildingControl = new lacdt.BuildingControl(render, { width: 350, height: '85vh', position: 'right', zIndex: 1000 });
      const toolControl = new lacdt.ToolboxControl(render, { width: 350, height: '85vh', position: 'right', zIndex: 1000 });
      const plottingControl = new lacdt.PlottingControl(render, { configPath: './plot_data.json' });

      sidebarControlRef.current.registerPanel('plotting', plottingControl);
      sidebarControlRef.current.registerPanel('3DTile', tilesetSearchControl);
      sidebarControlRef.current.registerPanel('layer', layerControl);
      sidebarControlRef.current.registerPanel('building', buildingControl);
      sidebarControlRef.current.registerPanel('scene', sceneControl);
      sidebarControlRef.current.registerPanel('toolbox', toolControl);

      engineRef.current.plot.onPick((info) => {
        console.log('Picked:', info);
        const sceneSystem = render.getSystem('scene');
        const propertyGroups = sceneSystem.getObjectProperties(info);
        sceneControl.updatePropertyPanel(info, propertyGroups);
      });
    };

    initEngine();

    return () => {
      if (viewerRef.current) {
        viewerRef.current.destroy();
      }
    };
  }, []);

  return (
    <div className="digital-twin-viewer" style={{ width: '100%', height: '100vh', position: 'relative' }}>
      <div ref={containerRef} style={{ width: '100%', height: '100%' }} />
      <div id="main-sidebar" style={{ position: 'absolute', top: 0, left: 0, height: '100%', zIndex: 100 }} />
      
      {loading && (
        <div style={{
          position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
          background: 'rgba(0,0,0,0.8)', color: '#fff', padding: '20px 40px',
          borderRadius: '8px', fontFamily: 'Arial, sans-serif', zIndex: 1000
        }}>
          正在加载数字孪生引擎...
        </div>
      )}
      
      {error && (
        <div style={{
          position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
          background: 'rgba(139, 0, 0, 0.9)', color: '#fff', padding: '20px 40px',
          borderRadius: '8px', fontFamily: 'Arial, sans-serif', zIndex: 1000
        }}>
          加载失败: {error}
        </div>
      )}
    </div>
  );
}

export default DigitalTwinViewer;
