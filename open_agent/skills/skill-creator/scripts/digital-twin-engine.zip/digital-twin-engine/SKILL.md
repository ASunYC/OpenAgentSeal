---
name: digital-twin-engine
description: This skill should be used when users want to build digital twin projects, 3D visualization platforms, or geospatial visualization applications based on HTML and JavaScript. This includes creating digital twin engines, twin platforms, or 3D visualization projects using Vue, React, or vanilla HTML/JS. The skill provides the LACDT (Lightweight Advanced Digital Twin) SDK integration with Cesium for geospatial visualization.
---

# Digital Twin Engine Skill

## Overview

This skill enables the creation of digital twin visualization projects using the LACDT (Lightweight Advanced Digital Twin) SDK built on Cesium. It provides a complete framework for building 3D geospatial visualization platforms, including terrain rendering, 3D tilesets, atmospheric effects, and interactive controls.

## When to Use This Skill

Use this skill when:
- Creating digital twin platforms or engines
- Building 3D geospatial visualization applications
- Developing projects with Vue, React, or vanilla HTML/JS that require 3D earth visualization
- Integrating Cesium-based 3D tiles, terrain, and atmospheric rendering
- Building interactive 3D scenes with environment controls, layer management, and plotting capabilities

## Core Capabilities

### 1. LACDT SDK Integration

The LACDT SDK provides a comprehensive set of tools for digital twin visualization:

- **Engine Core**: `LACDT.Engine` - Main rendering engine initialization
- **Environment Controls**: `lacdt.EnvironmentControl` - Lighting, shadows, atmosphere, volumetric clouds, post-processing
- **Scene Management**: `lacdt.SceneControl` - 3D object properties and interactions
- **Layer Control**: `lacdt.LayerControl` - Imagery layers and terrain management
- **Tileset Management**: `lacdt.TilesetSearchControl` - 3D Tiles loading and management
- **Building Control**: `lacdt.BuildingControl` - Building/facility management
- **Toolbox**: `lacdt.ToolboxControl` - Measurement and analysis tools
- **Plotting**: `lacdt.PlottingControl` - Geospatial plotting and annotation
- **Sidebar**: `lacdt.SidebarControl` - UI panel management

### 2. Required SDK Scripts

All projects must include these LACDT SDK scripts:

```html
<script src="https://io-qos.geovisearth.com/getfile/46/brainsim-cdn/open/sdk/lacdt.render.js"></script>
<script src="https://io-qos.geovisearth.com/getfile/46/brainsim-cdn/open/sdk/lacdt.plotting.js"></script>
```

### 3. Basic Project Structure

A minimal LACDT project requires:

```html
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Digital Twin Project</title>
  <style>
    html, body, #container { width: 100%; height: 100%; margin: 0; padding: 0; overflow: hidden; }
  </style>
</head>
<body>
  <div id="container"></div>
  
  <!-- LACDT SDK -->
  <script src="https://io-qos.geovisearth.com/getfile/46/brainsim-cdn/open/sdk/lacdt.render.js"></script>
  <script src="https://io-qos.geovisearth.com/getfile/46/brainsim-cdn/open/sdk/lacdt.plotting.js"></script>
  
  <script>
    // Initialize LACDT Engine
    var engine = new LACDT.Engine({ container: 'container' });
    var viewer = engine.viewer;
    
    // Set fixed time to noon for consistent lighting
    var now = new Date();
    now.setHours(12, 0, 0, 0);
    viewer.clock.currentTime = Cesium.JulianDate.fromDate(now);
    viewer.clock.shouldAnimate = false;
    
    // Add base imagery layer
    var token = 'your-token-here';
    var geovisMap = new Cesium.UrlTemplateImageryProvider({
      url: "https://tiles.geovisearth.com/base/v1/img/{z}/{x}/{y}?format=webp&tmsIds=w&token=" + token,
      maximumLevel: 18
    });
    viewer.imageryLayers.addImageryProvider(geovisMap);
  </script>
</body>
</html>
```

### 4. Environment Control Configuration

The `lacdt.EnvironmentControl` provides comprehensive rendering configuration:

```javascript
var environmentControl = new lacdt.EnvironmentControl({
  renderConfig: {
    engine: engine,
    viewer: viewer,
    
    // Directional light configuration
    directionalLight: {
      enabled: true,
      followSun: true,
      direction: new Cesium.Cartesian3(1.51, -0.11, 0.21),
      intensity: 2.5,
      color: Cesium.Color.fromCssColorString("#303941"),
      ambientIntensity: 0.7
    },
    
    // Shadow configuration
    shadow: {
      enabled: true,
      size: 4096,
      softShadows: true,
      darkness: 0.51,
      numBlurSamples: 24
    },
    
    // Atmosphere scattering
    atmosphereScattering: {
      enabled: true,
      atmosphereIntensity: 0.91
    },
    
    // Volumetric clouds
    volumetricClouds: {
      enabled: true,
      windVector: new Cesium.Cartesian3(5, 0, 0),
      cloudCover: 0.39,
      cloudBase: 2000.0,
      cloudTop: 6000.0
    },
    
    // Post-processing
    postProcessing: {
      enabled: true,
      hdrEnabled: true,
      fxaaEnabled: true,
      brightness: 1.0,
      contrast: 1.06,
      saturation: 1.4,
      gamma: 0.51,
      temperature: 6580,
      tint: -0.39
    }
  }
});
```

### 5. 3D Tiles Integration

Loading 3D tilesets with LACDT:

```javascript
(async function() {
  var url = 'https://path-to-tileset/tileset.json';
  
  var tileset = await Cesium.Cesium3DTileset.fromUrl(url, {
    clampToGround: true,
    shadows: Cesium.ShadowMode.ENABLED,
    maximumScreenSpaceError: 80,
    customShader: new Cesium.CustomShader({
      lightingModel: Cesium.LightingModel.PBR,
      fragmentShaderText: `
        void fragmentMain(FragmentInput fsInput, inout czm_modelMaterial material) {
          // Custom shader logic here
        }
      `
    })
  });
  
  // Memory management
  tileset.maximumMemoryUsage = 8192;
  tileset.cacheBytes = 4096 * 1024 * 1024;
  
  viewer.scene.primitives.add(tileset);
  await viewer.zoomTo(tileset);
})();
```

### 6. UI Controls Integration

Integrating sidebar and control panels:

```javascript
// Create sidebar
var sidebarControl = new lacdt.SidebarControl({
  containerId: 'main-sidebar',
  defaultActive: 'scene',
  initiallyExpanded: false,
  panelConfig: {
    defaultWidth: 400,
    defaultHeight: '85vh',
    sidebarExpandedWidth: 200,
    sidebarCollapsedWidth: 72,
    zIndex: 1000
  }
});

// Create various controls
var sceneControl = new lacdt.SceneControl(render, {
  width: 350, height: '85vh', position: 'right', zIndex: 1000
});

var layerControl = new lacdt.LayerControl(render, {
  width: 350, height: '85vh', position: 'right', zIndex: 1000
});

var tilesetSearchControl = new lacdt.TilesetSearchControl(render);

var buildingControl = new lacdt.BuildingControl(render, {
  width: 350, height: '85vh', position: 'right', zIndex: 1000
});

var toolControl = new lacdt.ToolboxControl(render, {
  width: 350, height: '85vh', position: 'right', zIndex: 1000
});

var plottingControl = new lacdt.PlottingControl(render, {
  configPath: './plot_data.json'
});

// Register panels with sidebar
sidebarControl.registerPanel('plotting', plottingControl);
sidebarControl.registerPanel('3DTile', tilesetSearchControl);
sidebarControl.registerPanel('layer', layerControl);
sidebarControl.registerPanel('building', buildingControl);
sidebarControl.registerPanel('scene', sceneControl);
sidebarControl.registerPanel('toolbox', toolControl);
```

## Resources

This skill includes bundled resources for building digital twin applications:

### assets/

Contains boilerplate HTML templates and starter projects for quick initialization:

- `html-starter/` - Basic HTML starter template with LACDT SDK
- `vue-starter/` - Vue.js integration template
- `react-starter/` - React integration template

### references/

Contains detailed API documentation and configuration references:

- `lacdt-api-reference.md` - Complete LACDT SDK API documentation
- `cesium-integration.md` - Cesium integration patterns and best practices
- `configuration-guide.md` - Detailed configuration options for all controls

### scripts/

Contains utility scripts for project setup and asset management:

- `setup-project.py` - Project initialization script
- `convert-coordinates.py` - Coordinate conversion utilities

## Best Practices

### Token Management

Always use a valid GeoVis Earth token for imagery and terrain services:

```javascript
let token = 'your-token-here';
```

### Performance Optimization

1. Set appropriate `maximumScreenSpaceError` for 3D tiles (default 80)
2. Configure `maximumMemoryUsage` and `cacheBytes` for tileset memory management
3. Use appropriate imagery provider `maximumLevel` (typically 18)
4. Disable clock animation when not needed: `viewer.clock.shouldAnimate = false`

### Memory Management

```javascript
tileset.maximumMemoryUsage = 8192;  // MB
tileset.cacheBytes = 4096 * 1024 * 1024;  // Bytes
```

### Event Handling

```javascript
// Pick events
engine.plot.onPick(function(info) {
  console.log('Picked:', info);
  // Update property panels, etc.
});

// Building click events
tilesetManager.updateConfig({
  enableMouseMove: true,
  onBuildingClick: function(building, event) {
    console.log('Building clicked:', building);
  }
});
```

## Integration Patterns

### Vue.js Integration

```vue
<template>
  <div ref="container" class="cesium-container"></div>
</template>

<script>
export default {
  mounted() {
    this.initEngine();
  },
  methods: {
    initEngine() {
      this.engine = new LACDT.Engine({ 
        container: this.$refs.container 
      });
      // Configure viewer...
    }
  }
};
</script>

<style>
.cesium-container { width: 100%; height: 100vh; }
</style>
```

### React Integration

```jsx
import { useEffect, useRef } from 'react';

function DigitalTwinViewer() {
  const containerRef = useRef(null);
  const engineRef = useRef(null);
  
  useEffect(() => {
    if (containerRef.current && !engineRef.current) {
      engineRef.current = new LACDT.Engine({ 
        container: containerRef.current 
      });
      // Configure viewer...
    }
    
    return () => {
      // Cleanup if needed
    };
  }, []);
  
  return <div ref={containerRef} style={{ width: '100%', height: '100vh' }} />;
}

export default DigitalTwinViewer;
```

## Common Issues and Solutions

### CORS Errors with Imagery

Ensure the imagery provider URL supports CORS or use a proxy:

```javascript
var imageryProvider = new Cesium.UrlTemplateImageryProvider({
  url: 'https://your-proxy.com/tiles/{z}/{x}/{y}',
  // ...
});
```

### Token Expiration

Implement token refresh logic:

```javascript
function refreshToken() {
  // Fetch new token from your auth endpoint
  return fetch('/api/token').then(r => r.json());
}

// Periodically refresh
setInterval(() => {
  refreshToken().then(newToken => {
    token = newToken;
    // Update imagery layers with new token
  });
}, 3600000); // Every hour
```

### Performance with Large Tilesets

For large 3D tilesets, implement level-of-detail strategies:

```javascript
var tileset = await Cesium.Cesium3DTileset.fromUrl(url, {
  maximumScreenSpaceError: 64, // Lower = higher quality, higher = better performance
  maximumMemoryUsage: 4096,    // MB
  dynamicScreenSpaceError: true,
  dynamicScreenSpaceErrorDensity: 0.00278,
  dynamicScreenSpaceErrorFactor: 4.0
});
```

## Additional Resources

- **LACDT SDK Documentation**: See `references/lacdt-api-reference.md`
- **Cesium Documentation**: https://cesium.com/docs/
- **GeoVis Earth Platform**: https://www.geovisearth.com/
- **Starter Templates**: See `assets/` directory for ready-to-use project templates

## Changelog

### v1.0.0
- Initial release
- Basic LACDT SDK integration
- HTML/Vue/React starter templates
- Complete API reference documentation
