# Cesium Integration Patterns

## Overview

LACDT is built on top of Cesium, the leading open-source JavaScript library for 3D globes and maps. Understanding the integration between LACDT and Cesium is essential for advanced usage.

## Cesium Viewer Access

The underlying Cesium viewer is accessible through the LACDT Engine:

```javascript
var engine = new LACDT.Engine({ container: 'container' });
var viewer = engine.viewer;  // This is the Cesium.Viewer instance
```

## Common Cesium Patterns

### Camera Control

```javascript
// Fly to a location
viewer.camera.flyTo({
  destination: Cesium.Cartesian3.fromDegrees(lon, lat, height),
  orientation: {
    heading: Cesium.Math.toRadians(0),
    pitch: Cesium.Math.toRadians(-45),
    roll: 0.0
  }
});

// Set view immediately
viewer.camera.setView({
  destination: Cesium.Cartesian3.fromDegrees(lon, lat, height)
});

// Get current camera position
var cameraPosition = viewer.camera.position;
var cartographic = Cesium.Cartographic.fromCartesian(cameraPosition);
var longitude = Cesium.Math.toDegrees(cartographic.longitude);
var latitude = Cesium.Math.toDegrees(cartographic.latitude);
var height = cartographic.height;
```

### Entity Management

```javascript
// Add an entity
var entity = viewer.entities.add({
  position: Cesium.Cartesian3.fromDegrees(lon, lat, height),
  point: {
    pixelSize: 10,
    color: Cesium.Color.RED
  },
  label: {
    text: 'Marker',
    font: '14pt sans-serif',
    fillColor: Cesium.Color.WHITE
  }
});

// Remove an entity
viewer.entities.remove(entity);

// Remove all entities
viewer.entities.removeAll();

// Get entity by ID
var entity = viewer.entities.getById('myEntity');
```

### Imagery Layers

```javascript
// Add imagery layer
var imageryLayer = viewer.imageryLayers.addImageryProvider(
  new Cesium.UrlTemplateImageryProvider({
    url: 'https://example.com/tiles/{z}/{x}/{y}.png'
  })
);

// Remove imagery layer
viewer.imageryLayers.remove(imageryLayer);

// Lower/raise layer
viewer.imageryLayers.lower(imageryLayer);
viewer.imageryLayers.raise(imageryLayer);

// Set layer opacity
imageryLayer.alpha = 0.5;

// Set layer brightness
imageryLayer.brightness = 1.5;
```

### Terrain

```javascript
// Set terrain provider
viewer.terrainProvider = await Cesium.CesiumTerrainProvider.fromUrl(
  'https://example.com/terrain'
);

// Get terrain height at position
var height = await viewer.scene.sampleHeight(
  Cesium.Cartographic.fromDegrees(lon, lat)
);
```

### Screen Space Events

```javascript
// Get screen space event handler
var handler = new Cesium.ScreenSpaceEventHandler(viewer.scene.canvas);

// Left click
handler.setInputAction(function(event) {
  var pickedObject = viewer.scene.pick(event.position);
  if (pickedObject) {
    console.log('Clicked:', pickedObject);
  }
}, Cesium.ScreenSpaceEventType.LEFT_CLICK);

// Mouse move
handler.setInputAction(function(event) {
  var pickedObject = viewer.scene.pick(event.endPosition);
  viewer.canvas.style.cursor = pickedObject ? 'pointer' : 'default';
}, Cesium.ScreenSpaceEventType.MOUSE_MOVE);

// Remove handler
handler.destroy();
```

## LACDT-Cesium Integration Points

### Render System

The LACDT render system provides access to Cesium primitives:

```javascript
var render = environmentControl.render;

// Access Cesium scene
var cesiumScene = render.scene;

// Access Cesium globe
var cesiumGlobe = render.globe;
```

### Custom Shaders with LACDT

When using LACDT's custom shader support, the shader code is passed to Cesium's CustomShader:

```javascript
var tileset = await Cesium.Cesium3DTileset.fromUrl(url, {
  customShader: new Cesium.CustomShader({
    lightingModel: Cesium.LightingModel.PBR,
    fragmentShaderText: `
      void fragmentMain(FragmentInput fsInput, inout czm_modelMaterial material) {
        // Custom shading logic
        material.diffuse = vec3(1.0, 0.0, 0.0); // Red color
      }
    `
  })
});
```

## Performance Considerations

### Cesium Performance with LACDT

1. **Request Render Mode**: Enable request render mode when not animating:
```javascript
var engine = new LACDT.Engine({
  container: 'container',
  viewerOptions: {
    requestRenderMode: true,
    maximumRenderTimeChange: Infinity
  }
});
```

2. **Frustum Culling**: Ensure frustum culling is enabled for tilesets:
```javascript
tileset.cullWithChildrenBounds = true;
tileset.cullRequestsWhileMoving = true;
```

3. **Memory Management**: Control tileset memory usage:
```javascript
tileset.maximumMemoryUsage = 4096; // MB
tileset.cacheBytes = 2048 * 1024 * 1024; // Bytes
```

## Debugging

### Enable Cesium Debugging

```javascript
// Show frames per second
viewer.scene.debugShowFramesPerSecond = true;

// Show draw commands
viewer.scene.debugShowCommands = true;

// Show depth buffer
viewer.scene.debugShowDepth = true;
```

### LACDT-Specific Debugging

```javascript
// Log all LACDT events
engine.plot.onPick(function(info) {
  console.log('LACDT Pick Event:', info);
});

// Check render system status
console.log('Render Systems:', render.getSystems());
```
