# LACDT Configuration Guide

## Environment Control Configuration

### Complete Configuration Example

```javascript
var environmentControl = new lacdt.EnvironmentControl({
  renderConfig: {
    engine: engine,
    visible: false,
    viewer: viewer,
    
    // Directional Light Configuration
    directionalLight: {
      enabled: false,
      followSun: true,
      direction: new Cesium.Cartesian3(1.51, -0.11, 0.21),
      intensity: 2.5,
      color: Cesium.Color.fromCssColorString("#303941"),
      ambientIntensity: 0.7
    },
    
    // Shadow Configuration
    shadow: {
      enabled: false,
      size: 4096,
      softShadows: true,
      darkness: 0.51,
      numBlurSamples: 24,
      shadowColor: new Cesium.Color(0.012, 0.078, 0.227, 1.0),
      shadowBlend: 0.01
    },
    
    // Atmosphere Scattering Configuration
    atmosphereScattering: {
      enabled: false,
      atmosphereIntensity: 0.91,
      rayleighIntensity: 1.0,
      mieIntensity: 1.0,
      absorptionIntensity: 1.0,
      bDensity: 0.01,
      bColor: Cesium.Color.fromCssColorString("#b6d3f5ff"),
      baseBetaR_R: 5.8e-6,
      baseBetaR_G: 13.5e-6,
      baseBetaR_B: 23.1e-6,
      baseBetaM_R: 20e-6,
      baseBetaM_G: 20e-6,
      baseBetaM_B: 20e-6,
      baseBetaA_R: 2.04e-5,
      baseBetaA_G: 4.97e-5,
      baseBetaA_B: 1.95e-6,
      hR: 8.5e3,
      hM: 3.2e3,
      hA: 30e3,
      absorption_falloff: 4e3,
      groundHeight: 6360e3,
      atmosphereThickness: 60e3,
      enableGroundMix: true
    },
    
    // Volumetric Clouds Configuration
    volumetricClouds: {
      enabled: false,
      windVector: new Cesium.Cartesian3(5, 0, 0),
      cloudCover: 0.39,
      cloudBase: 2000.0,
      cloudTop: 6000.0,
      cloudLightIntensity: 5.3,
      cloudIntensity: 1.0
    },
    
    // Post-Processing Configuration
    postProcessing: {
      enabled: false,
      hdrEnabled: true,
      fxaaEnabled: true,
      brightness: 1.0,
      contrast: 1.06,
      saturation: 1.4,
      gamma: 0.51,
      temperature: 6580,
      tint: -0.39,
      shadowColor: new Cesium.Color(0.012, 0.078, 0.227, 1.0),
      shadowBlend: 0.01
    }
  }
});
```

## Control Configuration Patterns

### SceneControl Options

```javascript
var sceneControl = new lacdt.SceneControl(render, {
  width: 350,        // Panel width in pixels or percentage
  height: '85vh',    // Panel height
  position: 'right', // 'left' or 'right'
  zIndex: 1000       // CSS z-index
});
```

### SidebarControl Options

```javascript
var sidebarControl = new lacdt.SidebarControl({
  containerId: 'main-sidebar',    // DOM container ID
  defaultActive: 'scene',         // Default active panel ID
  initiallyExpanded: false,     // Initial sidebar state
  panelConfig: {
    defaultWidth: 400,          // Default panel width
    defaultHeight: '85vh',      // Default panel height
    sidebarExpandedWidth: 200,  // Sidebar width when expanded
    sidebarCollapsedWidth: 72,  // Sidebar width when collapsed
    zIndex: 1000                // CSS z-index
  }
});
```

### Tileset Configuration

```javascript
var tileset = await Cesium.Cesium3DTileset.fromUrl(url, {
  // Performance
  maximumScreenSpaceError: 80,     // Lower = better quality, higher = better performance
  maximumMemoryUsage: 8192,       // MB - Maximum memory for this tileset
  
  // Visual quality
  luminanceAtZenith: 0.5,
  imageBasedLightingFactor: new Cesium.Cartesian2(1, 0.6),
  shadows: Cesium.ShadowMode.ENABLED,
  
  // Culling
  cullWithChildrenBounds: true,
  cullRequestsWhileMoving: true,
  cullRequestsWhileMovingMultiplier: 60.0,
  
  // Loading
  preloadWhenHidden: true,
  preloadFlightDestinations: true,
  preferLeaves: true,
  
  // Dynamic SSE
  dynamicScreenSpaceError: true,
  dynamicScreenSpaceErrorDensity: 0.00278,
  dynamicScreenSpaceErrorFactor: 4.0,
  dynamicScreenSpaceErrorHeightFalloff: 0.25,
  
  // Custom shaders
  customShader: new Cesium.CustomShader({
    lightingModel: Cesium.LightingModel.PBR,
    fragmentShaderText: `
      void fragmentMain(FragmentInput fsInput, inout czm_modelMaterial material) {
        // Custom shading
      }
    `
  })
});
```

## Best Practices

### 1. Memory Management

```javascript
// Set memory limits
tileset.maximumMemoryUsage = 4096;
tileset.cacheBytes = 2048 * 1024 * 1024;

// Clean up on destroy
function destroy() {
  if (viewer) {
    viewer.destroy();
    viewer = null;
  }
  if (tileset) {
    tileset.destroy();
    tileset = null;
  }
}
```

### 2. Performance Optimization

```javascript
// Enable request render mode
var engine = new LACDT.Engine({
  container: 'container',
  viewerOptions: {
    requestRenderMode: true,
    maximumRenderTimeChange: Infinity,
    targetFrameRate: 60
  }
});

// Optimize tileset loading
tileset.preloadWhenHidden = true;
tileset.preloadFlightDestinations = true;
tileset.preferLeaves = true;
```

### 3. Error Handling

```javascript
async function initTileset(url) {
  try {
    var tileset = await Cesium.Cesium3DTileset.fromUrl(url, {
      maximumScreenSpaceError: 80
    });
    
    tileset.tileFailed.addEventListener(function(error) {
      console.warn('Tile failed to load:', error);
    });
    
    viewer.scene.primitives.add(tileset);
    return tileset;
    
  } catch (error) {
    console.error('Failed to load tileset:', error);
    throw error;
  }
}
```

---

## Configuration Presets

### Day/Night Cycle Presets

```javascript
// Day preset
const dayPreset = {
  directionalLight: {
    enabled: true,
    followSun: true,
    intensity: 2.5,
    ambientIntensity: 0.7
  },
  shadow: { enabled: true, darkness: 0.3 },
  atmosphereScattering: { enabled: true, atmosphereIntensity: 1.0 }
};

// Night preset
const nightPreset = {
  directionalLight: {
    enabled: true,
    intensity: 0.3,
    ambientIntensity: 0.2
  },
  shadow: { enabled: false },
  atmosphereScattering: { enabled: true, atmosphereIntensity: 0.3 }
};
```

### Quality Presets

```javascript
// Low quality (for mobile/low-end devices)
const lowQuality = {
  maximumScreenSpaceError: 128,
  maximumMemoryUsage: 2048,
  shadow: { enabled: false },
  postProcessing: { enabled: false }
};

// High quality (for desktop/high-end devices)
const highQuality = {
  maximumScreenSpaceError: 32,
  maximumMemoryUsage: 8192,
  shadow: { enabled: true, size: 4096 },
  postProcessing: { enabled: true, fxaaEnabled: true }
};
```
