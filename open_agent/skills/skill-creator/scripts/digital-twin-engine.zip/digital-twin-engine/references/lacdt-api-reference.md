# LACDT SDK API Reference

## Overview

The LACDT (Lightweight Advanced Digital Twin) SDK provides a comprehensive set of tools for building 3D geospatial visualization applications on top of Cesium.

## Core Classes

### LACDT.Engine

The main engine class that initializes the Cesium viewer and provides the foundation for all other LACDT components.

```javascript
var engine = new LACDT.Engine(options);
```

**Constructor Options:**

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `container` | String/Element | required | DOM element ID or reference for the viewer |
| `viewerOptions` | Object | {} | Additional Cesium Viewer options |

**Properties:**

| Property | Type | Description |
|----------|------|-------------|
| `viewer` | Cesium.Viewer | The underlying Cesium viewer instance |
| `plot` | LACDT.Plot | Plot system for handling interactions |

---

### lacdt.EnvironmentControl

Manages environmental rendering settings including lighting, shadows, atmosphere, clouds, and post-processing.

```javascript
var environmentControl = new lacdt.EnvironmentControl(options);
```

**Constructor Options:**

| Option | Type | Description |
|--------|------|-------------|
| `renderConfig` | Object | Complete rendering configuration |

**RenderConfig Properties:**

#### Directional Light

```javascript
directionalLight: {
  enabled: Boolean,           // Enable directional light
  followSun: Boolean,         // Light follows sun position
  direction: Cartesian3,      // Light direction vector
  intensity: Number,          // Light intensity (default: 2.5)
  color: Color,             // Light color
  ambientIntensity: Number  // Ambient light intensity
}
```

#### Shadows

```javascript
shadow: {
  enabled: Boolean,       // Enable shadows
  size: Number,         // Shadow map size (default: 4096)
  softShadows: Boolean, // Enable soft shadows
  darkness: Number,     // Shadow darkness (0-1)
  numBlurSamples: Number // Blur sample count
}
```

#### Atmosphere Scattering

```javascript
atmosphereScattering: {
  enabled: Boolean,                // Enable atmospheric scattering
  atmosphereIntensity: Number,   // Atmosphere intensity
  rayleighIntensity: Number,      // Rayleigh scattering intensity
  mieIntensity: Number,          // Mie scattering intensity
  absorptionIntensity: Number,   // Absorption intensity
  bDensity: Number,              // Density factor
  bColor: Color,               // Base color
  // ... (see full configuration in examples)
}
```

#### Volumetric Clouds

```javascript
volumetricClouds: {
  enabled: Boolean,              // Enable volumetric clouds
  windVector: Cartesian3,      // Wind direction and speed
  cloudCover: Number,          // Cloud coverage (0-1)
  cloudBase: Number,           // Cloud base height (m)
  cloudTop: Number,            // Cloud top height (m)
  cloudLightIntensity: Number, // Cloud lighting intensity
  cloudIntensity: Number       // Overall cloud intensity
}
```

#### Post-Processing

```javascript
postProcessing: {
  enabled: Boolean,        // Enable post-processing
  hdrEnabled: Boolean,   // Enable HDR
  fxaaEnabled: Boolean,  // Enable FXAA anti-aliasing
  brightness: Number,    // Brightness adjustment
  contrast: Number,    // Contrast adjustment
  saturation: Number,   // Saturation adjustment
  gamma: Number,        // Gamma correction
  temperature: Number,  // Color temperature (K)
  tint: Number         // Color tint adjustment
}
```

---

### lacdt.SceneControl

Manages scene objects, properties, and interactions.

```javascript
var sceneControl = new lacdt.SceneControl(render, options);
```

**Constructor Parameters:**

| Parameter | Type | Description |
|-----------|------|-------------|
| `render` | LACDT.Render | The render system from EnvironmentControl |
| `options` | Object | Configuration options |

**Options:**

| Option | Type | Default | Description |
|--------|------|---------|-------------|
| `width` | Number/String | 350 | Panel width |
| `height` | Number/String | '85vh' | Panel height |
| `position` | String | 'right' | Panel position ('left' or 'right') |
| `zIndex` | Number | 1000 | Z-index for layering |

**Methods:**

#### updatePropertyPanel(info, propertyGroups)

Updates the property panel with object information.

```javascript
sceneControl.updatePropertyPanel(info, propertyGroups);
```

---

### lacdt.LayerControl

Manages imagery layers, terrain providers, and layer visibility.

```javascript
var layerControl = new lacdt.LayerControl(render, options);
```

**Constructor:** Same as SceneControl

**Features:**
- Toggle layer visibility
- Adjust layer opacity
- Reorder layers
- Add/remove imagery providers
- Manage terrain providers

---

### lacdt.TilesetSearchControl

Manages 3D tilesets search, loading, and configuration.

```javascript
var tilesetSearchControl = new lacdt.TilesetSearchControl(render);
```

**Features:**
- Search available 3D tilesets
- Load tilesets by URL
- Configure tileset properties
- Manage tileset visibility
- Memory management

---

### lacdt.BuildingControl

Manages building/facility data and visualization.

```javascript
var buildingControl = new lacdt.BuildingControl(render, options);
```

**Features:**
- Load building models
- Manage building attributes
- Building selection and highlighting
- Floor/level management

---

### lacdt.ToolboxControl

Provides measurement and analysis tools.

```javascript
var toolControl = new lacdt.ToolboxControl(render, options);
```

**Features:**
- Distance measurement
- Area measurement
- Height measurement
- Line of sight analysis
- Viewshed analysis

---

### lacdt.PlottingControl

Manages geospatial plotting and annotations.

```javascript
var plottingControl = new lacdt.PlottingControl(render, options);
```

**Options:**

| Option | Type | Description |
|--------|------|-------------|
| `configPath` | String | Path to plotting configuration JSON |

**Features:**
- Draw points, lines, polygons
- Add markers and labels
- Import/export GeoJSON
- Style customization

---

### lacdt.SidebarControl

Manages the main UI sidebar and panel navigation.

```javascript
var sidebarControl = new lacdt.SidebarControl(options);
```

**Options:**

| Option | Type | Description |
|--------|------|-------------|
| `containerId` | String | DOM ID for sidebar container |
| `defaultActive` | String | Default active panel ID |
| `initiallyExpanded` | Boolean | Initial expanded state |
| `panelConfig` | Object | Panel dimension configuration |

**Methods:**

#### registerPanel(id, control)

Registers a control panel with the sidebar.

```javascript
sidebarControl.registerPanel('scene', sceneControl);
```

---

## LACDT.Render System

The render system is obtained from `EnvironmentControl` and provides access to internal systems.

```javascript
var render = environmentControl.render;
```

### Systems Access

```javascript
// Get specific systems
var tilesetManager = render.getSystem('tileset');
var sceneSystem = render.getSystem('scene');
```

### Tileset System Configuration

```javascript
tilesetManager.updateConfig({
  enableMouseMove: true,
  onBuildingClick: function(building, event) {
    console.log('Building clicked:', building);
  }
});
```

---

## Event Handling

### Pick Events

Handle object selection/picking:

```javascript
engine.plot.onPick(function(info) {
  console.log('Picked object:', info);
  // Update UI, show properties, etc.
});
```

### Camera Events

```javascript
viewer.camera.changed.addEventListener(function() {
  console.log('Camera changed');
});

viewer.camera.moveEnd.addEventListener(function() {
  console.log('Camera movement ended');
});
```

---

## Token Management

### GeoVis Earth Token

A valid token is required for GeoVis Earth services:

```javascript
let token = 'your-token-here';
```

### Token Refresh Pattern

```javascript
async function refreshToken() {
  try {
    const response = await fetch('/api/token');
    const data = await response.json();
    return data.token;
  } catch (error) {
    console.error('Token refresh failed:', error);
    return null;
  }
}

// Periodic refresh
setInterval(async () => {
  const newToken = await refreshToken();
  if (newToken) {
    token = newToken;
    // Update imagery layers with new token
    updateImageryLayers(token);
  }
}, 3600000); // Every hour
```

---

## Type Definitions

For TypeScript users, here are the key type definitions:

```typescript
// LACDT Engine
interface EngineOptions {
  container: string | HTMLElement;
  viewerOptions?: Cesium.Viewer.ConstructorOptions;
}

// Environment Control
interface EnvironmentControlOptions {
  renderConfig: RenderConfig;
}

interface RenderConfig {
  engine: LACDT.Engine;
  viewer: Cesium.Viewer;
  visible?: boolean;
  directionalLight?: DirectionalLightConfig;
  shadow?: ShadowConfig;
  atmosphereScattering?: AtmosphereConfig;
  volumetricClouds?: CloudConfig;
  postProcessing?: PostProcessingConfig;
}

// Control Options
interface ControlOptions {
  width?: number | string;
  height?: number | string;
  position?: 'left' | 'right';
  zIndex?: number;
}
```

---

## Version History

### v1.0.0
- Initial LACDT SDK release
- Core engine and viewer
- Environment control system
- UI controls suite
- 3D tiles support
- React/Vue/HTML starters

---

## Support

For additional support and documentation:
- LACDT SDK Documentation: https://docs.lacdt.io
- Cesium Documentation: https://cesium.com/docs/
- GeoVis Earth: https://www.geovisearth.com/
